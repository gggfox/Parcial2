const mongoose = require( 'mongoose' );

/* Your code goes here */

module.exports = {
    
};